using System;
using UnityEngine;

[CreateAssetMenu(fileName = "ChipEncounter", menuName = "Scriptable Objects/ChipEncounter")]
public abstract class ChipEncounter : ScriptableObject
{
    public int headChance = 50;

    public virtual void Initialize() { }

    public virtual void FlipCoin(GameObject enemy) 
    {
        int randomValue = UnityEngine.Random.Range(0, 100);
        if (randomValue < headChance)
        {
            HeadChip(enemy);
        }
        else
        {
            TailChip();
        }
    }

    
    public abstract void HeadChip(GameObject enemy);

    public abstract void TailChip();
}
